import math
import random
import re

'''guess = random.randint(0, 100)
while True:
    suzi = int(input('请输入一个整数：'))
    if guess == suzi:
        print('答对了')
        break
    elif guess > suzi:
        print('猜小了')
    elif guess < suzi:
        print('猜大了')
'''

'''def check_password_strength(password):
    if len(password) < 8:
        return "弱"

    # 检查是否包含大写字母
    has_upper = re.search(r'[A-Z]', password) is not None
    # 检查是否包含小写字母
    has_lower = re.search(r'[a-z]', password) is not None
    # 检查是否包含数字
    has_digit = re.search(r'\d', password) is not None
    # 检查是否包含特殊字符
    has_special = re.search(r'[\W_]', password) is not None

    if has_upper and has_lower and has_digit and has_special:
        return "强"
    elif has_digit and (has_upper or has_lower):
        return "中"
    else:
        return "弱"


if __name__ == "__main__":
    password = input("请输入密码: ")
    strength = check_password_strength(password)
    print(f"密码: {password}, 强度: {strength}")'''
'''cities = {
    "北京": {"故宫": 4.5, "天坛": 4.2, "颐和园": 4.8},
    "上海": {"东方明珠": 4.6, "外滩": 4.3}
}
for city, attractions in cities.items():
    print(f"{city}的高评分景点:")
    for attraction, rating in attractions.items():
        if rating >= 4:
            print(f"  - {attraction}: {rating}")'''
'''r = float(input("请输入圆柱底面半径: "))
height = float(input("请输入圆柱的高: "))

surface_area = 2 * math.pi * r * (r + height)
volume = math.pi * r**2 * height

print(f"圆柱的表面积为: {surface_area:.2f}")
print(f"圆柱的体积为: {volume:.2f}")'''
#  len()计算长度; sum()列表元素求和; del lis删除列表; bool(lis)判断列表为空 true不为空; index(lis(' '))判断元素位置
#  lst.append('')在尾部添加元素; lst.extend([  ])尾部添加多个元素; lst.insert([1,' '])在指定位置添加; lst.pop(1)删除指定位置元素
#  lst.remove('')删除第一个匹配的元素; lst.clear()清空列表; lst.sort()排序函数reverse=Ture为降序
'''lst = [12, 5, 9, 18, 7, 15, 21, 4, 11, 27]
print(f"原始列表为: {lst}")
new = []
for n in lst:
    if n % 3 == 0:
        new.append(n)
new.sort(reverse=True)
print(f"能被3整除的降序排序后的列表: {new}")
newlst = [new[i:i+3] for i in range(0, len(new), 3)]
print(f"三个一组组合成的新列表: {newlst}")'''


'''def panduan(n):
    if n <= 1:
        return False
    for j in range(2, n):
        if n % j == 0:
            return False
        return True


if __name__ == "__main__":
    m = int(input('请输入一个正整数作为范围上限:'))
    lst = []
    for i in range(m):
        if panduan(i):
            lst.append(i)
    print(f"小于等于{m}的素数有：{lst}")'''


def tobu(n):
    aruku = 0
    m = len(n)

    for i in range(m):
        if i > aruku:
            return False
        aruku = max(aruku, i + n[i])

        if aruku >= m - 1:
            return True

    return False


if __name__ == "__main__":
    print(tobu([2, 3, 1, 1, 4]))
    print(tobu([3, 2, 1, 0, 4]))
