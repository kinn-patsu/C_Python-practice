import random
from math import sqrt


def how_pai(m):
    k = 0
    for i in range(m):
        x = random.random()
        y = random.random()
        if sqrt(x*x+y*y) <= 1:
            k = k+1
    return 4*k/m


def main():
    m = int(input('模拟次数为:'))
    print('蒙特卡洛模拟的值为: ', how_pai(m))


main()
