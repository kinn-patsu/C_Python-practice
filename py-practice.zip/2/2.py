def keisann(price, discount_rate):
    a = price*discount_rate
    if discount_rate<0:
        ku = '折扣率无效'
    elif discount_rate>1:
        ku = '折扣率无效'
    elif 0.9<discount_rate<1:
        ku = '优惠较大，建议购买'
    elif 0.8<discount_rate<0.9:
        ku = '一般优惠，可考虑购买'
    elif discount_rate<0.8:
        ku = '优惠较大'
    return a,ku


price = 100
discount_rate = 0.85

result = keisann(price, discount_rate)

if isinstance(result, tuple):
    discounted_price, message = result
    print(f"折扣后的价格是: {discounted_price:.2f}元")
    print(message)
else:
    print(result)
