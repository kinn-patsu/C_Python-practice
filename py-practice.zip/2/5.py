def panduan(n):
    if n <= 1:
        return False
    for j in range(2, n):
        if n % j == 0:
            return False
    return True


def wa1(m):
    k = 0
    for i in range(5):
        k += m % 10
        m = (m - m % 10)//10
    return k


def wa2(m):
    k = m % 10
    p = (m-k)//100
    return k+p


def main():
    for i in range(10000, 99999):
        if panduan(wa1(i)) and panduan(wa2(i)):
            print(i)


main()
