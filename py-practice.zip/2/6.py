def kapuyeka(m):
    m = str(m)
    s = ''.join(sorted(m))
    j = ''.join(sorted(m, reverse=True))
    print(f'{j}-{s}={int(j)-int(s)}')
    return int(j)-int(s)


def main():
    m = int(input('请输入一个四位数'))
    for i in range(7):
        m = kapuyeka(m)
        if m == 6174:
            break


main()
