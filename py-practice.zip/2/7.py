def cawsar(key, gennbenn):
    key_upper = key.upper()
    key_len = len(key)
    if len(gennbenn) == key_len:
        return key_upper
    else:
        return (key_upper*(len(gennbenn)//key_len))+key[0:len(gennbenn) % key_len]
#key[:len(gennbenn) % key_len] 0可省略


def kakusu(key, gennbenn):
    vigenere = []
    key = cawsar(key, gennbenn)
    for i in range(len(gennbenn)):
        char = gennbenn[i]
        if char.isalpha():   #判断是否是字符
            l = (ord(char.upper()) - ord('A')+ord(key[i])-ord('A')) % 26
            vigenere_char = chr(l + ord('A'))
            vigenere.append(vigenere_char)
        else:
            vigenere.append(char)
    return ''.join(vigenere) #列表中的字符串合并


def jiemi(key, vigenere):
    gennbenn = []
    key = cawsar(key, vigenere)
    for i in range(len(vigenere)):
        char = vigenere[i]
        if char.isalpha():
            l = (ord(char.upper()) - ord('A')-(ord(key[i])-ord('A'))) % 26
            gennbenn_char = chr(l + ord('A'))
            gennbenn.append(gennbenn_char)
        else:
            gennbenn.append(char)
    return ''.join(gennbenn)


gennbnn = 'hallo world123'


def main():
    key = input('请输入key:')
    print(f"加密后的文本为:{kakusu(key,gennbnn)}")
    print(f"解密后的原文为:{jiemi(key,kakusu(key,gennbnn))}")


main()

''''# 获取字母的 Unicode 码点
print(ord('A'))  # 输出: 65
print(ord('a'))  # 输出: 97
print(ord('!'))  # 输出: 33
'''