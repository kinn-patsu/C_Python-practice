height = 1.75
weight = 80.5

bmi = weight / (height ** 2)

print(f"小明的BMI指数是: {bmi:.2f}")

if bmi < 18.5:
    category = "过轻"
elif 18.5 <= bmi < 25:
    category = "正常"
elif 25 <= bmi < 28:
    category = "过重"
elif 28 <= bmi < 32:
    category = "肥胖"
else:
    category = "严重肥胖"

print(f"小明的体重分类是: {category}")