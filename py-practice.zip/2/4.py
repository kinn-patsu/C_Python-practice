import random
import math


def random_walk(steps):
    # 初始位置
    x, y = 0, 0
    max_distance = 0  # 用于记录最大距离

    for _ in range(steps):
        # 随机选择方向
        direction = random.choice(['up', 'down', 'left', 'right'])

        # 更新位置
        if direction == 'up':
            y += 1
        elif direction == 'down':
            y -= 1
        elif direction == 'left':
            x -= 1
        elif direction == 'right':
            x += 1

        # 计算当前位置到原点的距离
        distance = math.sqrt(x ** 2 + y ** 2)

        # 更新最大距离
        if distance > max_distance:
            max_distance = distance

    return max_distance


# 设置随机漫步的步数
steps = 100

max_distance = random_walk(steps)
print(f"在 {steps} 步的随机漫步中，距离原点的最远距离为: {max_distance:.2f}")
