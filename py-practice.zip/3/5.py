import struct
import random

filename = 'D:\\study\\py\\x1.bin'


def write_random_floats(filename, count=50):
    with open(filename, 'wb') as f:   #rb wb ab
        for _ in range(count):
            rand_float = random.uniform(0.0, 100.0)
            # 将浮点数转换为二进制并写入文件
            f.write(struct.pack('f', rand_float))


# 读取二进制文件并计算平均值
def read_floats_and_calculate_average(filename):
    floats = []
    with open(filename, 'rb') as f:
        while True:
            # 读取4字节（一个浮点数）
            bytes_read = f.read(4)
            if not bytes_read:
                break
            # 将二进制转换为浮点数
            float_value = struct.unpack('f', bytes_read)[0]
            floats.append(float_value)

    average = sum(floats) / len(floats) if floats else 0
    return average


def append_average_to_file(filename, average):
    with open(filename, 'ab') as f:
        f.write(struct.pack('f', average))


# 主程序
if __name__ == "__main__":
    write_random_floats(filename)
    average = read_floats_and_calculate_average(filename)
    print(f"平均值: {average}")
    append_average_to_file(filename, average)

'''a=425
print('二进制:{0:b},八进制:{0:o},十进制:{0:d},十六进制:{0:x},十六进制:{0:X}'.format(a))
print('{0:.2f},{0:.2e},{0:.2E},{0:.2%}'.format(a))#保留2位小数，科学计数法

输出结果如下：
二进制:110101001,八进制:651,十进制:425,十六进制:1a9,十六进制:1A9
425.00,4.25e+02,4.25E+02,42500.00%'''