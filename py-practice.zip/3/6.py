import random

def main():
    file = open('D:\\study\\py\\x2.txt', 'w',encoding='gbk')
    for i in range(50):
        y = random.randint(1000,9999)
        m = random.randint(1,12)
        d = random.randint(1,30)
        file.write(f"{y}-{m}-{d}\n")
    file.close()


    file = open('D:\\study\\py\\x2.txt', 'r', encoding='gbk')
    dates = file.readlines()  # 读取所有行,返回值是列表
    dates.sort()
    file.close()


    file = open('D:\\study\\py\\x3.txt', 'w', encoding='gbk')
    file.writelines(dates)
    file.close()


main()
