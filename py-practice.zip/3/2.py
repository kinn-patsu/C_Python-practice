class Animal:
    def make_sound(self):
        pass


class Dog(Animal):
    def make_sound(self):
        return "汪汪!"


class Cat(Animal):
    def make_sound(self):
        return "喵喵!"


class Bird(Animal):
    def make_sound(self):
        return "叽叽!"


def main():
    animals = [Dog(), Cat(), Bird()]

    for animal in animals:
        print(animal.make_sound())


if __name__ == "__main__":
    main()
