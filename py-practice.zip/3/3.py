class Vehicle:
    def __init__(self, brand, speed):
        self.__brand = brand  # 私有实例
        self.__speed = speed

    def get_info(self):
        return f"品牌: {self.__brand}, 速度: {self.__speed} km/h"

    def get_speed(self):
        return self.__speed

    def set_speed(self, speed):
        self.__speed = speed


class Car(Vehicle):
    def __init__(self, brand, speed, seats):
        super().__init__(brand, speed)
        self.seats = seats  # 公有实例

    def accelerate(self, amount):  # 注：不要子类中尝试直接访问父类的私有属性
        new_speed = self.get_speed() + amount
        self.set_speed(new_speed)

    def decelerate(self, amount):
        self.__speed = max(0, self.__speed - amount)

    def get_info(self):  # 方法重写
        return f"{super().get_info()}, 座位数: {self.seats}"


class Bicycle(Vehicle):
    def __init__(self, brand, speed, has_gear):  # 变速has_gear
        super().__init__(brand, speed)
        self.has_gear = has_gear

    def accelerate(self, amount):
        self.__speed += amount

    def decelerate(self, amount):
        self.__speed = max(0, self.__speed - amount)

    def get_info(self):
        return f"{super().get_info()}, 是否变速: {'是' if self.has_gear else '否'}"


class Motorcycle(Vehicle):
    def __init__(self, brand, speed, displacement):
        super().__init__(brand, speed)
        self.displacement = displacement

    def accelerate(self, amount):
        self.__speed += amount

    def decelerate(self, amount):
        self.__speed = max(0, self.__speed - amount)

    def get_info(self):
        return f"{super().get_info()}, 排量: {self.displacement}"


def main():
    car = Car("丰田", 120, 5)
    bicycle = Bicycle("山地车", 30, True)
    motorcycle = Motorcycle("哈雷", 100, 750)
    car.accelerate(20)

    vehicles = [car, bicycle, motorcycle]

    for vehicle in vehicles:
        print(vehicle.get_info())


if __name__ == "__main__":
    main()
