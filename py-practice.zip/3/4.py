class MusicPlayer:
    def __init__(self,playlist,n):
        self.__playlist = playlist
        self.__n = n

    def add_song(self,song):
        self.__playlist.append(song)

    def remove_song(self,song):
        self.__playlist.remove(song)

    def next_song(self):
        self.__n += 1
        print(f"播放下一首，{self.__playlist[self.__n]}")

    def previous_song(self):
        self.__n -= 1
        print(f"播放上一首，{self.__playlist[self.__n]}")

    def display(self):
        return f"{self.__playlist},当前正在播放{self.__playlist[self.__n]}"


def main():
    playlist = ['bright','orange','plun-にしな','アンビバレント']
    musicplayer = MusicPlayer(playlist,1)
    addsong = input('添加歌曲:')
    musicplayer.add_song(addsong)
    print(musicplayer.display())
    removesong = input('删除歌曲:')
    musicplayer.remove_song(removesong)
    print(musicplayer.display())
    musicplayer.next_song()
    musicplayer.previous_song()

if __name__ == "__main__":
    main()
