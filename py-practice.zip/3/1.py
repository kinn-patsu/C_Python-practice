class Person:
    def __init__(self, id, name):
        self.id = id              #实例属性
        self.name = name

    def display(self):            #实例方法
        return f"编号: {self.id}, 姓名: {self.name}"


class Student(Person):            #子类
    def __init__(self, id, name, class_name, score):
        super().__init__(id, name)  #调用父类的初始化方法
        self.class_name = class_name
        self.score = score

    def display(self):            #方法重写
        person_info = super().display()
        return f"{person_info}, 班级: {self.class_name}, 成绩: {self.score}"


class Teacher(Person):
    def __init__(self, id, name, title, department):    #编号、姓名、职称和部门
        super().__init__(id, name)
        self.title = title
        self.department = department

    def display(self):
        person_info = super().display()
        return f"{person_info}, 职称: {self.title}, 部门: {self.department}"


def main():
    students = []
    teachers = []
    id = input("请输入学生编号: ")
    name = input("请输入学生姓名: ")
    class_name = input("请输入班级: ")
    score = float(input("请输入成绩: "))
    student = Student(id, name, class_name, score)
    students.append(student)


    id = input("请输入教师编号: ")
    name = input("请输入教师姓名: ")
    title = input("请输入职称: ")
    department = input("请输入部门: ")
    teacher = Teacher(id, name, title, department)
    teachers.append(teacher)

    print("\n学生信息:")
    print(student.display())

    print("\n教师信息:")
    print(teacher.display())


if __name__ == "__main__":
    main()
