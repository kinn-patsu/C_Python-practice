import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import rcParams

# 设置字体
rcParams['font.family'] = 'SimHei'
rcParams['axes.unicode_minus'] = False

# 创建 SQLite 数据库并连接
conn = sqlite3.connect('environment_data.db')
cursor = conn.cursor()

# 创建数据表
cursor.execute('''
CREATE TABLE IF NOT EXISTS environment (
    time TEXT,
    temperature REAL,
    humidity REAL
)
''')

# 环境数据
data = {
    'time': [
        "2024-09-20 08:00", "2024-09-20 09:00", "2024-09-20 10:00",
        "2024-09-20 11:00", "2024-09-20 12:00", "2024-09-20 13:00",
        "2024-09-20 14:00", "2024-09-20 15:00", "2024-09-20 16:00",
        "2024-09-20 17:00", "2024-09-20 18:00", "2024-09-20 19:00",
        "2024-09-20 20:00", "2024-09-20 21:00", "2024-09-20 22:00",
        "2024-09-20 23:00", "2024-09-21 00:00", "2024-09-21 01:00",
        "2024-09-21 02:00", "2024-09-21 03:00", "2024-09-21 04:00",
        "2024-09-21 05:00", "2024-09-21 06:00", "2024-09-21 07:00",
        "2024-09-21 08:00", "2024-09-21 09:00"
    ],
    'temperature': [
        25, 26, 27, 28, 29, 30, 31, 32, 30, 29, 28, 27,
        26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15,
        None, 15  # 替换为 None 以处理异常值
    ],
    'humidity': [
        60, 58, 55, 52, 50, 48, 45, 42, 40, 38, 35, 32,
        30, 28, 25, 22, 20, 18, 15, 12, 10, 8, 6, 4,
        10, None  # 替换为 None 以处理异常值
    ]
}

# 插入数据
df = pd.DataFrame(data)
df['time'] = pd.to_datetime(df['time'])  # 确保时间格式正确
df.to_sql('environment', conn, if_exists='replace', index=False)

# 从数据库读取数据
df = pd.read_sql_query("SELECT * FROM environment", conn)

# 数据预处理：去除异常值（None）
df = df.dropna()

# 转换时间列为 datetime 格式（再次确认）
df['time'] = pd.to_datetime(df['time'])

# 绘制双坐标轴图
fig, ax1 = plt.subplots()

# 绘制温度折线图
ax1.set_ylabel('温度（摄氏度）', color='tab:red')
ax1.plot(df['temperature'], color='tab:red',marker='o', label='温度')
ax1.tick_params(axis='y', labelcolor='tab:red')

# 创建第二个 y 轴
ax2 = ax1.twinx()
ax2.set_ylabel('湿度（%）', color='tab:blue')
ax2.hist(df['humidity'], color='tab:blue', alpha=0.5, label='湿度', bins=10)
ax2.tick_params(axis='y', labelcolor='tab:blue')

fig.tight_layout()
plt.title('环境温度与湿度变化')
plt.show()

# 关闭数据库连接
conn.close()
