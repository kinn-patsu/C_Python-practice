import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from matplotlib import rcParams

# 设置字体
rcParams['font.family'] = 'SimHei'
rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 生成随机身高（150到200 cm）和体重（50到100 kg）的数据
np.random.seed(0)  # 设定随机种子以保证结果可重复，如果不设定种子，程序每次运行时生成的随机数会不同
heights = np.random.randint(150, 200, 100)
weights = np.random.randint(50, 100, 100)

# （h，w）合成数组
X = np.column_stack((heights, weights))

# 创建kmeans模型
kmeans = KMeans(n_clusters=3, random_state=0)  #生成聚类的数量为3，随机种子为0
kmeans.fit(X)  #将合成的二维数值导入kmeans

# 获取聚类结果
labels = kmeans.labels_  #这个属性包含了每个样本所属的簇的标签

plt.figure(figsize=(10, 6)) #创建一个新的图形窗口，设置图形的大小为 10 x 6 英寸
plt.scatter(X[:, 0], X[:, 1], c=labels, cmap='viridis', marker='o', edgecolor='k', s=50)
#c=labels 使用聚类的标签 labels 为每个点上色，点的颜色会根据它们所属的簇来区分
#cmap='viridis'指定使用的颜色映射（colormap）
#edgecolor='k'边缘颜色为黑色
#s=50 点的大小为50

plt.title('身高体重的 K-means 聚类结果')
plt.xlabel('身高 (cm)')
plt.ylabel('体重 (kg)')
#plt.legend() 生成图例
#plt.grid() 生成网格
plt.show() #显示图形
