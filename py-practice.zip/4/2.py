import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
import numpy as np

# 创建房屋数据 DataFrame
data = {
    'area': [120, 180, 250, 100, 150, 80, 90, 140, 170, 200,
             110, 160, 95, 130, 220, 75, 105, 185, 210, 145,
             85, 175, 230, 125, 98, 155, 240, 135, 70, 190],
    'year_built': [2020, 2015, 2010, 1995, 2005, 1985, 1990,
                   2000, 2012, 2018, 2008, 2011, 1998, 2003,
                   2014, 1988, 1999, 2009, 2017, 2006, 1992,
                   2013, 2016, 2007, 1996, 2012, 2019, 2004,
                   1986, 2010],
    'condition': ['全新', '较新', '较新', '老旧', '较新', '老旧',
                  '老旧', '较新', '较新', '全新', '较新', '全新',
                  '老旧', '较新', '较新', '老旧', '老旧', '较新',
                  '全新', '较新', '老旧', '较新', '全新', '较新',
                  '老旧', '较新', '老旧', '较新', '全新', '较新']
}
df = pd.DataFrame(data)

# 分离特征和标签
X = df[['area', 'year_built']]
y = df['condition']

# 分割数据集为训练集和测试集（80%训练，20%测试）
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 使用 KNN 分类器
knn = KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train, y_train)

# 随机选取6组测试数据
sample_indices = np.random.choice(X_test.index, size=6, replace=False)
X_sample = X_test.loc[sample_indices]
y_sample_true = y_test.loc[sample_indices]

# 进行预测
y_sample_pred = knn.predict(X_sample)

# 计算准确率
accuracy = accuracy_score(y_sample_true, y_sample_pred)

# 输出结果
print(X_sample)
print(y_sample_pred)
print("准确率:", accuracy)
