import matplotlib.pyplot as plt
from matplotlib import rcParams

# 设置字体
rcParams['font.family'] = 'SimHei'
rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 收集的数据
time = [0, 3, 6, 9, 12, 15, 18]
co2 = [500, 480, 550, 600, 580, 620, 650]

# 创建折线图
plt.plot(time, co2, color='red', marker='o')   #'^'：三角形 's'：方形 'D'：菱形 '*'：星形 'o'表示将数据点标记为圆圈

# 添加标题和轴标签
plt.title('室内二氧化碳浓度变化图')
plt.xlabel('时刻（小时）')
plt.ylabel('二氧化碳浓度（ppm）')

# 显示图形
plt.show()
